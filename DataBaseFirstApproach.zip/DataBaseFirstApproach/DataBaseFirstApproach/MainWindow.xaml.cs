﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataBaseFirstApproach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //Training_23Jan19_PuneEntities context = new Training_23Jan19_PuneEntities();
            //dgStudent.ItemsSource = context.Student_master.ToList();
            ShowData();
        }
        public void ShowData()
        {
            Training_23Jan19_PuneEntities context = new Training_23Jan19_PuneEntities();
            dgStudent.ItemsSource = context.Student_master.ToList();
        }

       
            
        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            Student_master stud = new Student_master();
            stud.Stud_Code = Convert.ToDecimal(txtStudent_Code.Text);
            stud.Stud_Name = txtName.Text;
            stud.Dept_Code = Convert.ToDecimal(txtDeptCode.Text);
            stud.Stud_Dob = Convert.ToDateTime(txtDob.Text);
            stud.Address = txtAddress.Text;

            Training_23Jan19_PuneEntities context = new Training_23Jan19_PuneEntities();
            context.Student_master.Add(stud);
            int recordsAffected = context.SaveChanges();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Student Record added successfully");
                ShowData();
            }
            else
                MessageBox.Show("Student record not added");
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            Training_23Jan19_PuneEntities context = new Training_23Jan19_PuneEntities();
            Student_master stud = context.Student_master.Find(Convert.ToDecimal(txtStudent_Code.Text));
            if (stud != null)
            {
                gridStud.DataContext = stud;
                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;
            }
            else
                MessageBox.Show("Student not found");
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Training_23Jan19_PuneEntities context = new Training_23Jan19_PuneEntities();
            Student_master stud = context.Student_master.Find(Convert.ToDecimal(txtStudent_Code.Text));

            stud.Stud_Name = txtName.Text;
            stud.Dept_Code = Convert.ToDecimal(txtDeptCode.Text);
            stud.Stud_Dob = Convert.ToDateTime(txtDob.Text);
            stud.Address = txtAddress.Text;

            int recordsAffected = context.SaveChanges();
            if (recordsAffected > 0)
            {
                MessageBox.Show("Student updated Successfully");
                ShowData();
            }
            else
                MessageBox.Show("Student not updated");
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            Training_23Jan19_PuneEntities context = new Training_23Jan19_PuneEntities();
            Student_master stud = context.Student_master.Find(Convert.ToDecimal(txtStudent_Code.Text));
            context.Student_master.Remove(stud);
            int recordsAffected = context.SaveChanges();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Student deleted Successfully");
                ShowData();
            }
            else
                MessageBox.Show("Student not deleted");
        }
    }
}
